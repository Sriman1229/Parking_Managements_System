import mysql.connector
import json
from datetime import datetime

class DBOperation():

    def __init__(self):
        file=open("./config.json","r")
        datadic=json.loads(file.read())
        file.close()
        self.mydb=mysql.connector.connect(host="localhost",user="root",passwd="Adit@2004",database="parking4")


    def CreateTables(self):
        cursor=self.mydb.cursor()
        cursor.execute("DROP TABLE if exists admin")
        cursor.execute("DROP TABLE if exists slots")
        cursor.execute("DROP TABLE if exists vehicles")
        cursor.execute("DROP TABLE if exists payments")
        cursor.execute("DROP TABLE if exists parking_analytics")
        cursor.execute("DROP TABLE if exists support")
        cursor.execute("DROP TABLE if exists users")
        cursor.execute("DROP TABLE if exists staff")
        cursor.execute("CREATE TABLE admin (id int(255) AUTO_INCREMENT PRIMARY KEY,username varchar(30),password varchar(30),created_at varchar(30))")
        cursor.execute("CREATE TABLE slots (id int(255) AUTO_INCREMENT PRIMARY KEY,vehicle_id varchar(30),space_for int(25),is_empty int(25))")
        cursor.execute("CREATE TABLE vehicles (id int(255) AUTO_INCREMENT PRIMARY KEY,name varchar(30),mobile varchar(30),entry_time varchar(30),exit_time varchar(30),is_exit varchar(30),vehicle_no varchar(30),vehicle_type varchar(30),created_at varchar(30),updated_at varchar(30))")
        cursor.close()

    def InsertOneTimeData(self,space_for_two,space_for_four):
        cursor=self.mydb.cursor()
        for x in range(space_for_two):
            cursor.execute("INSERT into slots (space_for,is_empty) values ('2','1')")
            self.mydb.commit()

        for x in range(space_for_four):
            cursor.execute("INSERT into slots (space_for,is_empty) values ('4','1')")
            self.mydb.commit()
        cursor.close()

    def InsertAdmin(self,username,password):
        cursor=self.mydb.cursor()
        val=(username,password)
        cursor.execute("INSERT into admin (username,password) values (%s,%s)",val)
        self.mydb.commit()
        cursor.close()

    def doAdminLogin(self,username,pasword):
        cursor=self.mydb.cursor()
        cursor.execute("select * from admin where username='"+username+"' and password='"+pasword+"'")
        data=cursor.fetchall()
        cursor.close()
        if len(data)>0:
            return True
        else:
            return False

    def getSlotSpace(self):
        cursor=self.mydb.cursor()
        cursor.execute("select * from slots")
        data=cursor.fetchall()
        cursor.close()
        return data

    def getCurrentVehicle(self):
        cursor=self.mydb.cursor()
        cursor.execute("select * from vehicles where is_exit='0'")
        data=cursor.fetchall()
        cursor.close()
        return data

    def getAllVehicle(self):
        cursor=self.mydb.cursor()
        cursor.execute("select * from vehicles where is_exit='1'")
        data=cursor.fetchall()
        cursor.close()
        return data

    def AddVehicles(self,name,vehicleno,mobile,vehicle_type):
        spacid=self.spaceAvailable(vehicle_type)
        if spacid:
            currentdata=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            data=(name,mobile,str(currentdata),'','0',vehicleno,str(currentdata),str(currentdata),vehicle_type)
            cursor=self.mydb.cursor()
            cursor.execute("INSERT into vehicles (name,mobile,entry_time,exit_time,is_exit,vehicle_no,created_at,updated_at,vehicle_type) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)",data)
            self.mydb.commit()
            lastid=cursor.lastrowid
            cursor.execute("UPDATE slots set vehicle_id='"+str(lastid)+"',is_empty='0' where id='"+str(spacid)+"'")
            self.mydb.commit()
            cursor.close()
            return True
        else:
            return "No Space Available for Parking"


    def spaceAvailable(self,v_type):
        cursor=self.mydb.cursor()
        cursor.execute("select * from slots where is_empty='1' and space_for='"+str(v_type)+"'")
        data=cursor.fetchall()
        cursor.close()

        if len(data)>0:
            return data[0][0]
        else:
            return False

    def exitVehicle(self,id):
        cursor=self.mydb.cursor()
        currentdata = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("UPDATE slots set is_empty='1',vehicle_id='' where vehicle_id='"+id+"'")
        self.mydb.commit()
        cursor.execute("UPDATE vehicles set is_exit='1',exit_time='"+currentdata+"' where id='" + id + "'")
        self.mydb.commit()

    def addPayment(self, vehicle_id, amount, payment_method, user_name, mobile_number, vehicle_number, parking_duration):
        try:
            cursor = self.mydb.cursor()

            insert_query = "INSERT INTO payments (vehicle_id, amount, payment_time, payment_method, user_name, mobile_number, vehicle_number, parking_duration) VALUES (%s, %s, NOW(), %s, %s, %s, %s, %s)"
            payment_data = (vehicle_id, amount, payment_method, user_name, mobile_number, vehicle_number, parking_duration)
            cursor.execute(insert_query, payment_data)

            self.mydb.commit()

            cursor.close()
            return True

        except mysql.connector.Error as error:
            print("Failed to insert payment information into the database:", error)
            return False    

    def get_daily_analytics(self, date):
        try:
            cursor = self.mydb.cursor(dictionary=True)

            query = "SELECT total_vehicles, total_revenue, average_parking_duration FROM parking_analytics WHERE `date` = %s"
            cursor.execute(query, (date,))

            analytics_data = cursor.fetchone()  # Assuming there's only one entry per date
            cursor.close()
            return analytics_data

        except mysql.connector.Error as error:
            print("Failed to fetch daily analytics:", error)
            return None


    def get_monthly_revenue(self, month, year):
        try:
            cursor = self.mydb.cursor(dictionary=True)

            query = "SELECT SUM(total_revenue) AS monthly_revenue FROM parking_analytics WHERE YEAR(date) = %s AND MONTH(date) = %s"
            cursor.execute(query, (year, month))

            monthly_revenue = cursor.fetchone()
            cursor.close()
            return monthly_revenue['monthly_revenue']

        except mysql.connector.Error as error:
            print("Failed to fetch monthly revenue:", error)
            return None
    def checkAdminPassword(self, password):
        try:
            cursor = self.mydb.cursor()
            query = "SELECT COUNT(*) FROM admin WHERE password = %s"
            cursor.execute(query, (password,))
            result = cursor.fetchone()
            cursor.close()
            return result[0] == 1
        except mysql.connector.Error as error:
            print("Failed to check admin password:", error)
            return False
    def getAllUsers(self):
        cursor = self.mydb.cursor()
        query = "SELECT * FROM users"
        cursor.execute(query)
        return cursor.fetchall()
    def addUser(self, username, email, password_hash):
        try:
            cursor = self.mydb.cursor()
            insert_query = "INSERT INTO users (username, email, password_hash, registration_date) VALUES (%s, %s, %s, NOW())"
            user_data = (username, email, password_hash)
            cursor.execute(insert_query, user_data)
            self.mydb.commit()
            cursor.close()
            return True
        except mysql.connector.Error as error:
            print("Failed to add user:", error)
            return False

    def removeUser(self, user_id):
        try:
            cursor = self.mydb.cursor()
            delete_query = "DELETE FROM users WHERE user_id = %s"
            cursor.execute(delete_query, (user_id,))
            self.mydb.commit()
            cursor.close()
            return True
        except mysql.connector.Error as error:
            print("Failed to remove user:", error)
            return False
    def addStaff(self, name, contact_number, email=None, position=None, shift_start=None, shift_end=None):
        try:
            cursor = self.mydb.cursor()

            insert_query = "INSERT INTO staff (name, contact_number, email, position, shift_start, shift_end) VALUES (%s, %s, %s, %s, %s, %s)"
            staff_data = (name, contact_number, email, position, shift_start, shift_end)
            cursor.execute(insert_query, staff_data)

            self.mydb.commit()

            cursor.close()
            return True

        except mysql.connector.Error as error:
            print("Failed to insert staff information into the database:", error)
            return False

    def updateStaff(self, staff_id, name=None, contact_number=None, email=None, position=None, shift_start=None, shift_end=None):
        try:
            cursor = self.mydb.cursor()

            update_query = "UPDATE staff SET"
            update_values = []

            if name:
                update_query += " name = %s,"
                update_values.append(name)
            if contact_number:
                update_query += " contact_number = %s,"
                update_values.append(contact_number)
            if email:
                update_query += " email = %s,"
                update_values.append(email)
            if position:
                update_query += " position = %s,"
                update_values.append(position)
            if shift_start:
                update_query += " shift_start = %s,"
                update_values.append(shift_start)
            if shift_end:
                update_query += " shift_end = %s,"
                update_values.append(shift_end)

            update_query = update_query.rstrip(',') + " WHERE id = %s"
            update_values.append(staff_id)

            cursor.execute(update_query, update_values)
            self.mydb.commit()

            cursor.close()
            return True

        except mysql.connector.Error as error:
            print("Failed to update staff information in the database:", error)
            return False

    def removeStaff(self, staff_id):
        try:
            cursor = self.mydb.cursor()

            delete_query = "DELETE FROM staff WHERE id = %s"
            cursor.execute(delete_query, (staff_id,))

            self.mydb.commit()

            cursor.close()
            return True

        except mysql.connector.Error as error:
            print("Failed to remove staff from the database:", error)
            return False     
    def getEntryTime(self, vehicle_id):
    # Assuming you have a table named 'vehicles' with a column 'entry_time'
        cursor = self.mydb.cursor()
        cursor.execute("SELECT entry_time FROM vehicles WHERE id = %s", (vehicle_id,))
        entry_time = cursor.fetchone()[0]
        return entry_time
    
    def getVehicleType(self, vehicle_id):
        # Execute a query to retrieve the vehicle type based on the vehicle ID
        cursor = self.mydb.cursor()
        query = "SELECT vehicle_type FROM vehicles WHERE id = %s"
        cursor.execute(query, (vehicle_id,))
        result = cursor.fetchone()
        if result:
            return result[0]  # Return the vehicle type
        else:
            return None  # Return None if the vehicle ID is not found
        
        
        
    def addSupportTicket(self, user_id, subject, description, status):
        try:
            # Execute SQL query to insert support ticket into the database
            query = "INSERT INTO support_tickets (user_id, subject, description, status) VALUES (%s, %s, %s, %s)"
            cursor = self.mydb.cursor()
            cursor.execute(query, (user_id, subject, description, status))
            self.mydb.commit()  # Commit the transaction
            return True  # Return True if successful
        except mysql.connector.Error as error:
            print("Failed to add support ticket:", error)
            return False  # Return False if unsuccessful


    
    def getAllSupportTickets(self):
        try:
            # Execute SQL query to fetch support tickets
            cursor = self.mydb.cursor()
            query = "SELECT user_id, subject, description, status FROM support_tickets"
            cursor.execute(query)

            # Fetch all rows from the result set
            support_tickets = cursor.fetchall()

            return support_tickets
        except mysql.connector.Error as error:
            print("Failed to fetch support tickets:", error)
            return []    
        
    def changeSupportTicketStatus(self, ticket_id, new_status):
        try:
            # Update the status of the support ticket in the database
            cursor = self.mydb.cursor()
            query = "UPDATE support_tickets SET status = %s WHERE ticket_id = %s"
            cursor.execute(query, (new_status, ticket_id))
            self.mydb.commit()
            return True
        except Exception as e:
            print("Error:", e)
            self.mydb.rollback()
            return False    
    
    def close_connection(self):
        self.mydb.close()