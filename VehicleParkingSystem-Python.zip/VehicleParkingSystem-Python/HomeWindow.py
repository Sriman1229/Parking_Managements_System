from PyQt5.QtWidgets import QWidget,QMainWindow,QPushButton,QLineEdit,QLabel,QVBoxLayout,QHBoxLayout,QFrame,QGridLayout,QComboBox,QTableWidget,QTableWidgetItem
from DataBaseOperation import DBOperation
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QHeaderView,qApp
import PyQt5.QtGui
from collections import defaultdict
from datetime import datetime
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QDialog
import mysql.connector
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDialog
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QInputDialog
import uuid




class AdminPasswordDialog(QDialog):
    def __init__(self):
        super().__init__()

        # Create widgets for the dialog
        self.password_label = QLabel("Enter Admin Password:")
        self.password_input = QLineEdit()
        self.submit_button = QPushButton("Submit")
        self.submit_button.clicked.connect(self.accept)

        # Create layout for the dialog
        layout = QVBoxLayout()
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.submit_button)

        self.setLayout(layout)

    def getPassword(self):
        return self.password_input.text()
    
class HomeScreen(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Home")
        self.dbOperation=DBOperation()
        self.setGeometry(100, 100, 600, 600)
        widget=QWidget()
        widget.setStyleSheet("background-color: #D3D3D3;")
        layout_horizontal=QHBoxLayout()
        menu_vertical_layout=QVBoxLayout()
        self.user_name_input = QLineEdit()
        self.mobile_number_input = QLineEdit()
        self.vehicle_number_input = QLineEdit()
        self.payment_method_dropdown = QComboBox()


        self.vtype = QComboBox()
        self.btn_home=QPushButton("Home")
        self.btn_add = QPushButton("Add Vehicle")
        self.btn_manage = QPushButton("Manage Vehicle")
        self.btn_history = QPushButton("History")
        self.btn_payments = QPushButton("Payments")
        self.btn_analytics = QPushButton("Analytics")
        self.btn_support = QPushButton("Tickets")
        self.btn_users = QPushButton("Users")
        self.btn_staff = QPushButton("staff")

        menu_vertical_layout.setContentsMargins(0,0,0,0)
        menu_vertical_layout.setSpacing(0)
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.btn_home.clicked.connect(self.showHome)
        self.btn_add.clicked.connect(self.showAdd)
        self.btn_manage.clicked.connect(self.showManage)
        self.btn_history.clicked.connect(self.showHistory)
        self.btn_payments.clicked.connect(self.showPayments)
        self.btn_analytics.clicked.connect(self.showAnalytics)
        self.btn_support.clicked.connect(self.showSupport)
        self.btn_users.clicked.connect(self.showUsers)
        self.btn_staff.clicked.connect(self.showStaff)


        menu_frame=QFrame()
        menu_vertical_layout.addWidget(self.btn_home)
        menu_vertical_layout.addWidget(self.btn_add)
        menu_vertical_layout.addWidget(self.btn_manage)
        menu_vertical_layout.addWidget(self.btn_history)
        menu_vertical_layout.addWidget(self.btn_payments)
        menu_vertical_layout.addWidget(self.btn_analytics)
        menu_vertical_layout.addWidget(self.btn_support)
        menu_vertical_layout.addWidget(self.btn_users)
        menu_vertical_layout.addWidget(self.btn_staff)
        menu_vertical_layout.addStretch()
        menu_frame.setLayout(menu_vertical_layout)
        #menu_frame.setMinimumWidth(200)
        #menu_frame.setMaximumHeight(200)




        parent_vertical=QVBoxLayout()
        parent_vertical.setContentsMargins(0,0,0,0)
        self.vertical_1=QVBoxLayout()
        self.addHomePageData()


        self.vertical_2=QVBoxLayout()
        self.vertical_2.setContentsMargins(0,0,0,0)
        self.addAddStudentPage()

        self.vertical_3=QVBoxLayout()
        self.vertical_3.setContentsMargins(0,0,0,0)
        self.addManagePage()

        self.vertical_4=QVBoxLayout()
        self.vertical_4.setContentsMargins(0,0,0,0)
        self.addHistoryPage()

        self.vertical_5=QVBoxLayout()
        self.vertical_5.setContentsMargins(0, 0, 0, 0)
        self.addPaymentsPage()

        self.vertical_6=QVBoxLayout()
        self.vertical_6.setContentsMargins(0,0,0,0)
        self.addAnalyticsPage()

        self.vertical_7=QVBoxLayout()
        self.vertical_7.setContentsMargins(0,0,0,0)
        self.addSupportPage()

        self.vertical_8=QVBoxLayout()
        self.vertical_8.setContentsMargins(0,0,0,0)
        self.addUsersPage()

        self.vertical_8.addWidget(self.users_table)
        self.vertical_8.setContentsMargins(0, 0, 0, 0)  # Set a fixed size for the layout

        # Populate the users table
        self.populateUsersTable()

        self.vertical_9 = QVBoxLayout()
        self.addStaffPage()
        self.vertical_9.setContentsMargins(0, 0, 0, 0)  # Set a fixed size for the layout
        
        self.frame_1=QFrame()
        self.frame_1.setMinimumWidth(self.width())
        self.frame_1.setMaximumWidth(self.width())
        self.frame_1.setMaximumHeight(self.width())
        self.frame_1.setMaximumHeight(self.width())

        self.frame_1.setLayout(self.vertical_1)
        self.frame_2=QFrame()
        self.frame_2.setLayout(self.vertical_2)
        self.frame_3=QFrame()
        self.frame_3.setLayout(self.vertical_3)
        self.frame_4=QFrame()
        self.frame_4.setLayout(self.vertical_4)
        self.frame_5=QFrame()
        self.frame_5.setLayout(self.vertical_5)
        self.frame_6=QFrame()
        self.frame_6.setLayout(self.vertical_6)
        self.frame_7=QFrame()
        self.frame_7.setLayout(self.vertical_7)
        self.frame_8=QFrame()
        self.frame_8.setLayout(self.vertical_8)
        self.frame_9=QFrame()
        self.frame_9.setLayout(self.vertical_9)



        parent_vertical.addWidget(self.frame_1)
        parent_vertical.addWidget(self.frame_2)
        parent_vertical.addWidget(self.frame_3)
        parent_vertical.addWidget(self.frame_4)
        parent_vertical.addWidget(self.frame_5)
        parent_vertical.addWidget(self.frame_6)
        parent_vertical.addWidget(self.frame_7)
        parent_vertical.addWidget(self.frame_8)
        parent_vertical.addWidget(self.frame_9)



        layout_horizontal.addWidget(menu_frame)
        layout_horizontal.addLayout(parent_vertical)
        layout_horizontal.setContentsMargins(0,0,0,0)
        parent_vertical.setContentsMargins(0,0,0,0)
        parent_vertical.addStretch()
        #menu_vertical_layout.addStretch()
        layout_horizontal.addStretch()
        widget.setLayout(layout_horizontal)

        self.frame_1.show()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()

        self.setCentralWidget(widget)

    def showStaff(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.show()


    def showUsers(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_9.hide()
        self.frame_8.show()
     

    def showSupport(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_7.show()
     

    def showAnalytics(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_6.show()
     

    def showPayments(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_5.show()

    def showHistory(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_4.show()

    def showManage(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_2.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_3.show()

    def showAdd(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_1.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_2.show()

    def showHome(self):
        self.btn_home.setStyleSheet("width:200px;height:80px;font-size:20px;background:#1A3668;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_add.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_manage.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_history.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_payments.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_analytics.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_support.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_users.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")
        self.btn_staff.setStyleSheet("width:200px;height:80px;font-size:20px;background:#A4866F;color:#fff;font-weight:bold;border:1px solid white")

        self.frame_2.hide()
        self.frame_3.hide()
        self.frame_4.hide()
        self.frame_5.hide()
        self.frame_6.hide()
        self.frame_7.hide()
        self.frame_8.hide()
        self.frame_9.hide()
        self.frame_1.show()

    def refreshHome(self):
        while self.gridLayout.count():
            child=self.gridLayout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        row=0
        i=0
        alldata=self.dbOperation.getSlotSpace()
        for data in alldata:
            label=QPushButton("Slot "+str(data[0])+" \n "+str(data[1]))

            if data[3]==1:
                label.setStyleSheet("background-color:green;color:white;padding:5px;width:100px;height:100px;border:1px solid white;text-align:center;font-weight:bold")
            else:
                label.setStyleSheet("background-color:red;color:white;padding:5px;width:100px;height:100px;border:1px solid white;text-align:center;font-weight:bold")

            if i%5==0:
                i=0
                row=row+1

            self.gridLayout.addWidget(label,row,i)
            i=i+1


    def addHomePageData(self):
        self.vertical_1.setContentsMargins(0,0,0,0)
        
        button=QPushButton("Refresh Slot")
        button.setStyleSheet("color:#fff;padding:8px 0px;font-size:20px;background:#696969;border:1px solid white")
        button.clicked.connect(self.refreshHome)

        vertical_layout=QVBoxLayout()
        vertical_layout.setContentsMargins(0,0,0,0)
        frame=QFrame()

        horizontal=QHBoxLayout()
        horizontal.setContentsMargins(0,0,0,0)
        vertical_layout.addLayout(horizontal)

        alldata=self.dbOperation.getSlotSpace()
        self.gridLayout=QGridLayout()
        self.gridLayout.setContentsMargins(0,0,0,0)
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setVerticalSpacing(0)
        vertical_layout.addWidget(button)
        vertical_layout.addLayout(self.gridLayout)

        row=0
        i=0
        for data in alldata:
            label=QPushButton("Slot "+str(data[0])+" \n "+str(data[1]))

            if data[3]==1:
                label.setStyleSheet("background-color:green;color:white;padding:5px;width:100px;height:100px;border:1px solid white;text-align:center;font-weight:bold")
            else:
                label.setStyleSheet("background-color:red;color:white;padding:5px;width:100px;height:100px;border:1px solid white;text-align:center;font-weight:bold")

            if i%5==0:
                i=0
                row=row+1

            self.gridLayout.addWidget(label,row,i)
            i=i+1

        frame.setLayout(vertical_layout)
        self.vertical_1.addWidget(frame)
        self.vertical_1.addStretch()

    def addAddStudentPage(self):
        layout=QVBoxLayout()
        frame=QFrame()


        name_label=QLabel("Name : ")
        name_label.setStyleSheet("color:black; background-color:white; padding:8px 0px;font-size:30px,border:5px black")
        name_label.setMinimumHeight(40)
        mobile_label=QLabel("Mobile : ")
        mobile_label.setStyleSheet("color:black;background-color:white;padding:8px 0px;font-size:30px.border:5px black")
        mobile_label.setMinimumHeight(40)
        vechicle_label=QLabel("Vehicle No : ")
        vechicle_label.setStyleSheet("color:black;background-color:white;padding:8px 0px;font-size:30px,border:5px black")
        vechicle_label.setMinimumHeight(40)
        vechicle_type=QLabel("Vehicle Type : ")
        vechicle_type.setStyleSheet("color:black;background-color:white; padding:8px 0px;font-size:30px,border:5px black")
        vechicle_type.setMinimumHeight(40)
        error_label=QLabel("")
        error_label.setStyleSheet("color:black;background-color:white;padding:8px 0px;font-size:30px,border:5px black")
        error_label.setMinimumHeight(40)

        name_input=QLineEdit()
        name_input.setStyleSheet("color:black;background-color: white;")
        name_input.setMinimumHeight(60)
        mobile_input=QLineEdit()
        mobile_input.setStyleSheet("color:black;background-color: white;")
        mobile_input.setMinimumHeight(60)
        vehicle_input=QLineEdit()
        vehicle_input.setStyleSheet("color:black;background-color: white;")
        vehicle_input.setMinimumHeight(60)
        vtype=QComboBox()
        vtype.setMinimumHeight(40)
        vtype.setStyleSheet("color:black;background-color: white;")
        vtype.addItem("2 Wheeler")
        vtype.addItem("4 Wheeler")
        vtype.setMinimumHeight(40)

        button=QPushButton("Add Vehicle")
        button.setStyleSheet("color:#fff;padding:8px 0px;font-size:20px;background:green;border:1px solid white")

        layout.addWidget(name_label)
        layout.addWidget(name_input)
        layout.addWidget(mobile_label)
        layout.addWidget(mobile_input)
        layout.addWidget(vechicle_label)
        layout.addWidget(vehicle_input)
        layout.addWidget(vechicle_type)
        layout.addWidget(vtype)
        layout.addWidget(button)
        layout.addWidget(error_label)

        layout.setContentsMargins(0,0,0,0)
        frame.setMinimumHeight(self.height())
        frame.setMinimumWidth(self.width())
        frame.setMaximumHeight(self.width())
        frame.setMaximumWidth(self.width())

        layout.addStretch()
        frame.setLayout(layout)
        button.clicked.connect(lambda:self.addVehicles(name_input.text(),vehicle_input.text(),mobile_input.text(),vtype.currentIndex(),error_label))
        self.vertical_2.addWidget(frame)

    def addVehicles(self,name,vehicleno,mobile,index,error_label):
        vtp=2
        if index==0:
            vtp=2
        else:
            vtp=4


        data=self.dbOperation.AddVehicles(name,vehicleno,mobile,str(vtp))
        if data==True:
            error_label.setText("Added Successfully")
        elif data==False:
            error_label.setText("Failed to Add Vehicle")
        else:
            error_label.setText(str(data))



    def addManagePage(self):
        data=self.dbOperation.getCurrentVehicle()
        self.table=QTableWidget()
        self.table.setStyleSheet("background:#fff")
        self.table.resize(self.width(),self.height())
        self.table.setRowCount(len(data))
        self.table.setColumnCount(7)

        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.setHorizontalHeaderItem(0,QTableWidgetItem("ID"))
        self.table.setHorizontalHeaderItem(1,QTableWidgetItem("Name"))
        self.table.setHorizontalHeaderItem(2,QTableWidgetItem("VEHICLE No"))
        self.table.setHorizontalHeaderItem(3,QTableWidgetItem("MOBILE"))
        self.table.setHorizontalHeaderItem(4,QTableWidgetItem("VEHICLE TYPE"))
        self.table.setHorizontalHeaderItem(5,QTableWidgetItem("ENTRY TIME"))
        self.table.setHorizontalHeaderItem(6,QTableWidgetItem("ACTION"))

        loop=0
        for smalldata in data:
            self.table.setItem(loop,0,QTableWidgetItem(str(smalldata[0])))
            self.table.setItem(loop,1,QTableWidgetItem(str(smalldata[1])))
            self.table.setItem(loop,2,QTableWidgetItem(str(smalldata[6])))
            self.table.setItem(loop,3,QTableWidgetItem(str(smalldata[2])))
            self.table.setItem(loop,4,QTableWidgetItem(str(smalldata[7])))
            self.table.setItem(loop,5,QTableWidgetItem(str(smalldata[3])))
            self.button_exit=QPushButton("Exit")
            self.button_exit.setStyleSheet("color:#fff;padding:8px 0px;font-size:20px;background:green;border:1px solid white")
            self.table.setCellWidget(loop,6,self.button_exit)
            self.button_exit.clicked.connect(self.exitCall)
            loop=loop+1

        frame=QFrame()
        layout=QVBoxLayout()
        button=QPushButton("Refresh")
        button.setStyleSheet("color:#fff;padding:8px 0px;font-size:20px;background:green;border:1px solid white")
        button.clicked.connect(self.refreshManage)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(0)
        layout.addWidget(button)
        layout.addWidget(self.table)
        frame.setLayout(layout)
        frame.setContentsMargins(0,0,0,0)
        frame.setMaximumWidth(self.width())
        frame.setMinimumWidth(self.width())
        frame.setMaximumHeight(self.height())
        frame.setMinimumHeight(self.height())
        self.vertical_3.addWidget(frame)
        self.vertical_3.addStretch()

    def refreshManage(self):
        data=self.dbOperation.getCurrentVehicle()
        self.table.setRowCount(len(data))
        self.table.setColumnCount(7)
        loop=0
        for smalldata in data:
            self.table.setItem(loop,0,QTableWidgetItem(str(smalldata[0])))
            self.table.setItem(loop,1,QTableWidgetItem(str(smalldata[1])))
            self.table.setItem(loop,2,QTableWidgetItem(str(smalldata[6])))
            self.table.setItem(loop,3,QTableWidgetItem(str(smalldata[2])))
            self.table.setItem(loop,4,QTableWidgetItem(str(smalldata[7])))
            self.table.setItem(loop,5,QTableWidgetItem(str(smalldata[3])))
            self.button_exit=QPushButton("Exit")
            self.table.setCellWidget(loop,6,self.button_exit)
            self.button_exit.clicked.connect(self.exitCall)
            loop=loop+1


    def refreshHistory(self):
        self.table1.clearContents()
        data=self.dbOperation.getAllVehicle()
        loop=0
        self.table1.setRowCount(len(data))
        self.table1.setColumnCount(7)
        for smalldata in data:
            self.table1.setItem(loop,0,QTableWidgetItem(str(smalldata[0])))
            self.table1.setItem(loop,1,QTableWidgetItem(str(smalldata[1])))
            self.table1.setItem(loop,2,QTableWidgetItem(str(smalldata[6])))
            self.table1.setItem(loop,3,QTableWidgetItem(str(smalldata[2])))
            self.table1.setItem(loop,4,QTableWidgetItem(str(smalldata[7])))
            self.table1.setItem(loop,5,QTableWidgetItem(str(smalldata[3])))
            self.table1.setItem(loop,6,QTableWidgetItem(str(smalldata[4])))
            loop=loop+1

    def addHistoryPage(self):
        data=self.dbOperation.getAllVehicle()
        self.table1=QTableWidget()
        self.table1.resize(self.width(),self.height())
        self.table1.setRowCount(len(data))
        self.table1.setStyleSheet("background:#fff")
        self.table1.setColumnCount(7)

        button=QPushButton("Refresh")
        button.setStyleSheet("color:#fff;padding:8px 0px;font-size:20px;background:green;border:1px solid white")
        button.clicked.connect(self.refreshHistory)


        self.table1.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table1.setHorizontalHeaderItem(0,QTableWidgetItem("ID"))
        self.table1.setHorizontalHeaderItem(1,QTableWidgetItem("Name"))
        self.table1.setHorizontalHeaderItem(2,QTableWidgetItem("VEHICLE No"))
        self.table1.setHorizontalHeaderItem(3,QTableWidgetItem("MOBILE"))
        self.table1.setHorizontalHeaderItem(4,QTableWidgetItem("VEHICLE TYPE"))
        self.table1.setHorizontalHeaderItem(5,QTableWidgetItem("ENTRY TIME"))
        self.table1.setHorizontalHeaderItem(6,QTableWidgetItem("EXIT TIME"))

        loop=0
        for smalldata in data:
            self.table1.setItem(loop,0,QTableWidgetItem(str(smalldata[0])))
            self.table1.setItem(loop,1,QTableWidgetItem(str(smalldata[1])))
            self.table1.setItem(loop,2,QTableWidgetItem(str(smalldata[6])))
            self.table1.setItem(loop,3,QTableWidgetItem(str(smalldata[2])))
            self.table1.setItem(loop,4,QTableWidgetItem(str(smalldata[7])))
            self.table1.setItem(loop,5,QTableWidgetItem(str(smalldata[3])))
            self.table1.setItem(loop,6,QTableWidgetItem(str(smalldata[4])))
            loop=loop+1

        self.frame5=QFrame()
        self.layout1=QVBoxLayout()
        self.layout1.setContentsMargins(0,0,0,0)
        self.layout1.setSpacing(0)
        self.layout1.addWidget(button)
        self.layout1.addWidget(self.table1)
        self.frame5.setLayout(self.layout1)
        self.frame5.setContentsMargins(0,0,0,0)
        self.frame5.setMaximumWidth(self.width())
        self.frame5.setMinimumWidth(self.width())
        self.frame5.setMaximumHeight(self.height())
        self.frame5.setMinimumHeight(self.height())
        self.vertical_4.addWidget(self.frame5)
        self.vertical_4.addStretch()


    def addPaymentsPage(self):
    # Clear any existing widgets in vertical layout
        while self.vertical_5.count():
            child = self.vertical_5.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        label_stylesheet = "color: black; font-size: 20px;"

    # Fetch vehicle IDs from the database
        vehicle_ids = self.dbOperation.getCurrentVehicle()

    # Create a label and dropdown menu for selecting vehicle ID
        vehicle_id_label = QLabel("Select Vehicle ID:")
        vehicle_id_label.setStyleSheet("color: black; font-size: 30")
        self.vehicle_id_dropdown = QComboBox()
        for vehicle in vehicle_ids:
            self.vehicle_id_dropdown.addItem(str(vehicle[0]))

        self.vehicle_id_dropdown.setStyleSheet("color: black; background-color: white;font-size: 30;")  
        self.vehicle_id_dropdown.setMinimumHeight(40)  

        self.refreshData()

    # Create labels and input fields for other payment details

        payment_method_label = QLabel("Payment Method:")
        payment_method_label.setStyleSheet("color: black; font-size: 30")
        self.payment_method_dropdown = QComboBox()
        self.payment_method_dropdown.addItems(["UPI", "Cash", "Credit/Debit Card"])
        self.payment_method_dropdown.setStyleSheet("color: black; background-color: white;font-size: 30;")
        payment_method_label.setMinimumHeight(40)
        self.payment_method_dropdown.setMinimumHeight(40)

        user_name_label = QLabel("User Name:")
        user_name_label.setStyleSheet("color: black; font-size: 30")
        self.user_name_input = QLineEdit()
        user_name_label.setMinimumHeight(40)
        self.user_name_input.setMinimumHeight(40)

        mobile_number_label = QLabel("Mobile Number:")
        mobile_number_label.setStyleSheet("color: black; font-size: 30")
        self.mobile_number_input = QLineEdit()
        mobile_number_label.setMinimumHeight(40)
        self.mobile_number_input.setMinimumHeight(40)

        vehicle_number_label = QLabel("Vehicle Number:")
        vehicle_number_label.setStyleSheet("color: black; font-size: 30")
        self.vehicle_number_input = QLineEdit()
        vehicle_number_label.setMinimumHeight(40)
        self.vehicle_number_input.setMinimumHeight(40)

        amount_label = QLabel("Amount:")
        amount_label.setStyleSheet("color: black; font-size: 30")
        self.amount_input = QLineEdit()
        self.amount_input.setStyleSheet("color: black; background-color: white;")
        self.amount_input.setMinimumHeight(40)
        amount_label.setMinimumHeight(40)

    # Calculate parking duration
        selected_vehicle_id = int(self.vehicle_id_dropdown.currentText())
        entry_time_str = self.dbOperation.getEntryTime(selected_vehicle_id)
        entry_time = datetime.strptime(entry_time_str, "%Y-%m-%d %H:%M:%S")

        current_time = datetime.now()
        parking_duration = (current_time - entry_time).total_seconds() / 3600
        

    # Display parking duration
        parking_duration_label = QLabel("Parking Duration:")
        self.parking_duration_input = QLineEdit(str(round(parking_duration, 2)))
        self.parking_duration_input.setReadOnly(True)
        self.parking_duration_input.setStyleSheet("color: black; background-color: white;")
        self.parking_duration_input.setMinimumHeight(40)
        parking_duration_label.setMinimumHeight(40)

    
    # Create a submit button
        submit_button = QPushButton("SUBMIT")
        submit_button.clicked.connect(self.submitPayment)
        submit_button.setStyleSheet("color: white; background-color: green;")

    # Create a refresh button
        refresh_button = QPushButton("REFRESH")
        refresh_button.clicked.connect(self.refreshData)
        refresh_button.setStyleSheet("color: white; background-color: green;")

    # Set stylesheets for labels and input fields
        labels = [vehicle_id_label, amount_label, payment_method_label, user_name_label, mobile_number_label, vehicle_number_label, parking_duration_label]
        inputs = [self.user_name_input, self.mobile_number_input, self.vehicle_number_input, self.amount_input]

        for label in labels:
            label.setStyleSheet("color: white;")  # White text color
        for input_field in inputs:
            input_field.setStyleSheet("color: black; background-color: white;")  # Black text on white background

    # Create a vertical layout to hold the widgets
        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(vehicle_id_label)
        vertical_layout.addWidget(self.vehicle_id_dropdown)
        vertical_layout.addWidget(amount_label)
        vertical_layout.addWidget(self.amount_input)
        vertical_layout.addWidget(payment_method_label)
        vertical_layout.addWidget(self.payment_method_dropdown)
        vertical_layout.addWidget(user_name_label)
        vertical_layout.addWidget(self.user_name_input)
        vertical_layout.addWidget(mobile_number_label)
        vertical_layout.addWidget(self.mobile_number_input)
        vertical_layout.addWidget(vehicle_number_label)
        vertical_layout.addWidget(self.vehicle_number_input)
        vertical_layout.addWidget(parking_duration_label)
        vertical_layout.addWidget(self.parking_duration_input)
        vertical_layout.addWidget(submit_button)
        vertical_layout.addWidget(refresh_button)

    # Add the vertical layout to the main vertical layout
        self.vertical_5.addLayout(vertical_layout)
        self.vertical_5.addStretch()

        vehicle_id_label.setStyleSheet(label_stylesheet)
        payment_method_label.setStyleSheet(label_stylesheet)
        user_name_label.setStyleSheet(label_stylesheet)
        mobile_number_label.setStyleSheet(label_stylesheet)
        vehicle_number_label.setStyleSheet(label_stylesheet)
        amount_label.setStyleSheet(label_stylesheet)
        parking_duration_label.setStyleSheet(label_stylesheet)


    def refreshData(self):
    # Get the selected vehicle ID
        selected_vehicle_id = int(self.vehicle_id_dropdown.currentText())

    # Fetch vehicle details from the database based on the selected vehicle ID
        vehicle_details = self.dbOperation.getCurrentVehicle()  # Remove the argument here
        if vehicle_details:
        # Find the details for the selected vehicle ID
            for vehicle in vehicle_details:
                if vehicle[0] == selected_vehicle_id:
                # Fill in the input fields with the fetched vehicle details
                    self.user_name_input.setText(vehicle[1])  # Assuming name is at index 1 in the tuple
                    self.mobile_number_input.setText(vehicle[2])  # Assuming mobile number is at index 2
                    self.vehicle_number_input.setText(vehicle[6])  # Assuming vehicle number is at index 6
                    break

    
    def submitPayment(self):
    # Retrieve input values from UI elements
        vehicle_id = int(self.vehicle_id_dropdown.currentText())
        payment_method = self.payment_method_dropdown.currentText()
        user_name = self.user_name_input.text()
        mobile_number = self.mobile_number_input.text()
        vehicle_number = self.vehicle_number_input.text()
        parking_duration = float(self.parking_duration_input.text())
        amount = self.amount_input.text()
        

        # Insert payment into database
        if self.dbOperation.addPayment(vehicle_id, amount, payment_method, user_name, mobile_number, vehicle_number, parking_duration):
            QMessageBox.information(self, "Success", "Payment added successfully.")
        else:
            QMessageBox.warning(self, "Error", "Failed to add payment.")
  
    def addAnalyticsPage(self):
    # Clear any existing widgets in vertical layout
        while self.vertical_6.count():
            child = self.vertical_6.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        try:
            # Fetch analytics data from the database for the current date
            today_date = datetime.now().date().strftime("%Y-%m-%d")
            analytics_data = self.dbOperation.get_daily_analytics(today_date)

            if analytics_data:
                # Create labels to display analytics details
                total_vehicles_label = QLabel(f"Total Vehicles: {analytics_data['total_vehicles']}")
                total_vehicles_label.setStyleSheet("color: white;")  # Change text color to white
                total_vehicles_label.setMinimumHeight(30)

                total_revenue_label = QLabel(f"Total Revenue: ${analytics_data['total_revenue']}")
                total_revenue_label.setStyleSheet("color: white;")  # Change text color to white
                total_revenue_label.setMinimumHeight(30)

                average_duration_label = QLabel(f"Average Parking Duration: {analytics_data['average_parking_duration']} hours")
                average_duration_label.setStyleSheet("color: white;")  # Change text color to white
                average_duration_label.setMinimumHeight(30)


                # Create a button to visualize analytics data
                visualize_button = QPushButton("Visualize Analytics")
                visualize_button.clicked.connect(self.visualizeAnalytics)
                visualize_button.setStyleSheet("background-color = white;")

                # Create a vertical layout to hold the widgets
                vertical_layout = QVBoxLayout()
                vertical_layout.addWidget(total_vehicles_label)
                vertical_layout.addWidget(total_revenue_label)
                vertical_layout.addWidget(average_duration_label)
                vertical_layout.addWidget(visualize_button)

                # Add the vertical layout to the main vertical layout
                self.vertical_layout.addLayout(vertical_layout)
                self.vertical_layout.addStretch()
            else:
                # Display a message if no analytics data is available
                no_data_label = QLabel("No analytics data available for the selected date.")
                self.vertical_6.addWidget(no_data_label)

        except mysql.connector.Error as error:
            print("Error:", error)


    def visualizeAnalytics(self):
        try:
            # Fetch analytics data from the database for the current date
            today_date = datetime.now().date().strftime("%Y-%m-%d")
            analytics_data = self.dbOperation.get_daily_analytics(today_date)

            if analytics_data:
                # Extract data for visualization
                labels = ['Total Vehicles', 'Total Revenue', 'Average Parking Duration']
                values = [analytics_data['total_vehicles'], analytics_data['total_revenue'], analytics_data['average_parking_duration']]

                # Create a bar plot
                plt.bar(labels, values)
                plt.title('Daily Analytics')
                plt.xlabel('Metrics')
                plt.ylabel('Values')
                plt.show()
            else:
                # Display a message if no analytics data is available
                print("No analytics data available for visualization.")

        except mysql.connector.Error as error:
            print("Error:", error)



    def addSupportPage(self):
        # Clear any existing widgets in vertical layout
        while self.vertical_7.count():
            child = self.vertical_7.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Create labels and input fields for support ticket details
        user_id_label = QLabel("User ID:")
        user_id_label.setStyleSheet("color: black;")
        self.user_id_input = QLineEdit()
        self.user_id_input.setStyleSheet("color: black; background-color: white;")
        user_id_label.setMinimumHeight(40)
        self.user_id_input.setMinimumHeight(40)

        subject_label = QLabel("Subject:")
        subject_label.setStyleSheet("color: black;")
        self.subject_input = QLineEdit()
        self.subject_input.setStyleSheet("color: black; background-color: white;")
        subject_label.setMinimumHeight(40)
        self.subject_input.setMinimumHeight(40)

        description_label = QLabel("Description:")
        description_label.setStyleSheet("color: black;")
        self.description_input = QLineEdit()
        self.description_input.setStyleSheet("color: black; background-color: white;")
        description_label.setMinimumHeight(40)
        self.description_input.setMinimumHeight(40)

        # Create a submit button
        submit_button = QPushButton("Submit")
        submit_button.setStyleSheet("color: white; background-color: green;")
        submit_button.clicked.connect(self.submitSupportTicket)

        # Create a table to display support tickets
        self.support_table = QTableWidget()
        self.support_table.setColumnCount(4)  # User ID, Subject, Description, Status
        self.support_table.setHorizontalHeaderLabels(["User ID", "Subject", "Description", "Status"])
        self.support_table.setStyleSheet("background-color: white;")


        self.support_table.setMinimumWidth(550)  # Set minimum width
        self.support_table.setMinimumHeight(450)  # Set minimum height

        # Fetch support tickets and populate the table
        self.populateSupportTable()

        # Create a vertical layout to hold the widgets
        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(user_id_label)
        vertical_layout.addWidget(self.user_id_input)
        vertical_layout.addWidget(subject_label)
        vertical_layout.addWidget(self.subject_input)
        vertical_layout.addWidget(description_label)
        vertical_layout.addWidget(self.description_input)
        vertical_layout.addWidget(submit_button)
        vertical_layout.addWidget(self.support_table)

        # Set background color for the main layout
        self.setStyleSheet("background-color: white;")

        # Add the vertical layout to the main vertical layout
        self.vertical_7.addLayout(vertical_layout)
        self.vertical_7.addStretch()

    def submitSupportTicket(self):
    # Generate a unique ticket ID
        existing_tickets_count = len(self.dbOperation.getAllSupportTickets())
        ticket_id = str(existing_tickets_count + 1)

        # Get input values from the input fields
        user_id = self.user_id_input.text()
        subject = self.subject_input.text()
        description = self.description_input.text()
        status = "Open"  # Default status

        # Call the addSupportTicket method from DBOperation to add the support ticket to the database
        success = self.dbOperation.addSupportTicket(user_id, subject, description, status)

        if success:
            print("Support ticket added successfully!")
            # Update the table after adding the ticket
            self.populateSupportTable()
        else:
            print("Failed to add support ticket.")


    def populateSupportTable(self):
    # Fetch support tickets from the database
        support_tickets = self.dbOperation.getAllSupportTickets()

        # Clear existing rows in the table
        self.support_table.setRowCount(0)

        # Populate the table with support ticket data
        for row_num, ticket in enumerate(support_tickets):
            self.support_table.insertRow(row_num)
            for col_num, data in enumerate(ticket):
                item = QTableWidgetItem(str(data))
                # Set columns "User ID", "Subject", and "Description" non-editable
                if col_num in [0, 1, 2]:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.support_table.setItem(row_num, col_num, item)

        # Connect slot for editing "Status" column
        self.support_table.itemDoubleClicked.connect(self.editSupportTicketStatus)

    def editSupportTicketStatus(self, item):
        # Check if the double-clicked column is "Status"
        if item.column() == 3:  # Assuming "Status" column is at index 3
            # Create the admin password dialog
            dialog = AdminPasswordDialog()
            if dialog.exec_() == QDialog.Accepted:
                # Get the entered password
                admin_password = dialog.getPassword()

                # Check if the admin password is correct
                if self.dbOperation.checkAdminPassword(admin_password):
                    # Prompt for new status
                    new_status, ok = QInputDialog.getText(self, "Enter New Status", "New Status:")
                    if ok:
                        # Get the row index
                        row_index = item.row()
                        # Get the ticket ID from the "User ID" column (assuming it's in the first column)
                        ticket_id = self.support_table.item(row_index, 0).text()
                        # Update the status in the database
                        success = self.dbOperation.changeSupportTicketStatus(ticket_id, new_status)
                        if success:
                            QMessageBox.information(self, "Success", "Support ticket status changed successfully.")
                            # Update the table after changing status
                            self.populateSupportTable()
                        else:
                            QMessageBox.warning(self, "Error", "Failed to change support ticket status.")
                else:
                    QMessageBox.warning(self, "Access Denied", "Incorrect admin password.")
    def addUsersPage(self):
        # Clear any existing widgets in vertical layout
        while self.vertical_8.count():
            child = self.vertical_8.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Create labels and input fields for user details
        username_label = QLabel("Username:")
        username_label.setStyleSheet("color: black;")
        self.username_input = QLineEdit()
        self.username_input.setStyleSheet("color: black; background-color: white;")
        username_label.setMinimumHeight(40)
        self.username_input.setMinimumHeight(40)

        email_label = QLabel("Email:")
        email_label.setStyleSheet("color: black;")
        self.email_input = QLineEdit()
        self.email_input.setStyleSheet("color: black; background-color: white;")
        email_label.setMinimumHeight(40)
        self.email_input.setMinimumHeight(40)

        password_label = QLabel("Password:")
        password_label.setStyleSheet("color: black;")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet("color:black; background-color: white;")
        password_label.setMinimumHeight(40)
        self.password_input.setMinimumHeight(40)
        # Create a button to add user
        add_user_button = QPushButton("Add User")
        add_user_button.clicked.connect(self.addUser)
        add_user_button.setStyleSheet("color:white; background-color: green;")
        add_user_button.setMinimumHeight(40)

        # Create a table to display existing users
        self.users_table = QTableWidget()
        self.users_table.setStyleSheet("color: black; background-color: white;")
        self.users_table.setColumnCount(4)
        self.users_table.setHorizontalHeaderLabels(["User ID", "Username", "Email", "Registration Date"])
        self.populateUsersTable()

        self.users_table.setMinimumWidth(550)  # Set minimum width
        self.users_table.setMinimumHeight(400)  # Set minimum height
        

        # Create a button to remove user
        remove_user_button = QPushButton("Remove User")
        remove_user_button.clicked.connect(self.removeUser)
        remove_user_button.setStyleSheet("background-color: red;")

        # Create a vertical layout to hold the widgets
        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(username_label)
        vertical_layout.addWidget(self.username_input)
        vertical_layout.addWidget(email_label)
        vertical_layout.addWidget(self.email_input)
        vertical_layout.addWidget(password_label)
        vertical_layout.addWidget(self.password_input)
        vertical_layout.addWidget(add_user_button)
        vertical_layout.addWidget(self.users_table)
        vertical_layout.addWidget(remove_user_button)

        self.setStyleSheet("background-color: white;")

        # Add the vertical layout to the main vertical layout
        self.vertical_8.addLayout(vertical_layout)
        self.vertical_8.addStretch()
    def setWidgetStyles(self, widget):
        widget.setStyleSheet("color: black; background-color: white; border: 5px solid grey; margin: 5px;")

    def populateUsersTable(self):
        # Fetch existing users from the database
        users = self.dbOperation.getAllUsers()

        # Clear existing rows in the table
        self.users_table.setRowCount(0)
        self.users_table.setStyleSheet("background-color: white;")

        # Get the current date
        current_date = datetime.now().strftime("%Y-%m-%d")

        # Populate the table with user data
        for row_num, user_data in enumerate(users):
            self.users_table.insertRow(row_num)
            for col_num, data in enumerate(user_data):
                # Display email in the "Email" column
                if col_num == 2:
                    item = QTableWidgetItem(str(data))
                    self.users_table.setItem(row_num, col_num, item)
                # Display registration date in the "Registration Date" column
                elif col_num == 3:
                    item = QTableWidgetItem(current_date)
                    self.users_table.setItem(row_num, col_num, item)
                # Hide password from the table
                elif col_num == 4:
                    continue
                else:
                    item = QTableWidgetItem(str(data))
                    self.users_table.setItem(row_num, col_num, item)
        
        # Resize the table horizontally and vertically
        table_width = 550  # Set the desired width in pixels
        table_height = 450  # Set the desired height in pixels
        

        # Resize columns to fit content
        self.users_table.resizeColumnsToContents()

        # Set email column width to a fixed size
        self.users_table.setColumnWidth(2, 250)  # Adjust the width as needed (200 pixels in this example)



    def addUser(self):
        # Get user details from input fields
        username = self.username_input.text()
        email = self.email_input.text()
        password = self.password_input.text()


        # Add user to the database
        if self.dbOperation.addUser(username, email, password):
            QMessageBox.information(self, "Success", "User added successfully.")
            self.populateUsersTable()
        else:
            QMessageBox.information(self, "error")
    def removeUser(self):
        # Get the selected row from the table
        selected_row = self.users_table.currentRow()
        if selected_row != -1:
            # Get the user_id of the selected user
            user_id = int(self.users_table.item(selected_row, 0).text())

            # Remove user from the database
            if self.dbOperation.removeUser(user_id):
                QMessageBox.information(self, "Success", "User removed successfully.")
                self.populateUsersTable()
            else:
                QMessageBox.information(self, "error", "User could not be removed.")
        else:
            QMessageBox.information(self, "error", "No user selected.")

    def addStaffPage(self):
        # Clear any existing widgets in vertical layout
        while self.vertical_9.count():
            child = self.vertical_9.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Create labels and input fields for staff details
        name_label = QLabel("Name:")
        name_label.setStyleSheet("color: black;")
        self.name_input = QLineEdit()
        self.name_input.setStyleSheet("color: black; background-color: white;")
        name_label.setMinimumHeight(40)
        self.name_input.setMinimumHeight(40)

        contact_number_label = QLabel("Contact Number:")
        self.contact_number_input = QLineEdit()
        contact_number_label.setMinimumHeight(40)
        self.contact_number_input.setStyleSheet("color: black; background-color: white;")
        contact_number_label.setStyleSheet("color: black;")
        self.contact_number_input.setMinimumHeight(40)

        email_label = QLabel("Email:")
        self.email_input = QLineEdit()
        email_label.setMinimumHeight(40)
        self.email_input.setStyleSheet("color: black; background-color: white;")
        email_label.setStyleSheet("color: black;")
        self.email_input.setMinimumHeight(40)

        position_label = QLabel("Position:")
        self.position_input = QLineEdit()
        position_label.setMinimumHeight(40)
        self.position_input.setStyleSheet("color: black; background-color: white;")
        position_label.setStyleSheet("color: black;")
        self.position_input.setMinimumHeight(40)


        # Create a submit button
        submit_button = QPushButton("Add Staff")
        submit_button.clicked.connect(self.addStaff)
        submit_button.setStyleSheet("color: white; background-color: green;")
        submit_button.setMinimumHeight(40)

        # Create a vertical layout to hold the widgets
        vertical_layout = QVBoxLayout()
        vertical_layout.addWidget(name_label)
        vertical_layout.addWidget(self.name_input)
        vertical_layout.addWidget(contact_number_label)
        vertical_layout.addWidget(self.contact_number_input)
        vertical_layout.addWidget(email_label)
        vertical_layout.addWidget(self.email_input)
        vertical_layout.addWidget(position_label)
        vertical_layout.addWidget(self.position_input)
        vertical_layout.addWidget(submit_button)

        # Add the vertical layout to the main vertical layout
        self.vertical_9.addLayout(vertical_layout)
        self.vertical_9.addStretch()

    def addStaff(self):
        name = self.name_input.text()
        contact_number = self.contact_number_input.text()
        email = self.email_input.text()
        position = self.position_input.text()

        # Validate input fields
        if not name or not contact_number:
            QMessageBox.warning(self, "Warning", "Name and Contact Number are required fields.")
            return

        # Call DBOperation method to add staff
        if self.dbOperation.addStaff(name, contact_number, email, position):
            QMessageBox.information(self, "Success", "Staff member added successfully.")
            # Clear input fields
            self.name_input.clear()
            self.contact_number_input.clear()
            self.email_input.clear()
            self.position_input.clear()
            self.shift_start_input.clear()
            self.shift_end_input.clear()
        else:
            QMessageBox.critical(self, "Error", "Failed to add staff member. Please try again.")          

    def exitCall(self):
        btton=self.sender()
        if btton:
            row=self.table.indexAt(btton.pos()).row()
            id =str(self.table.item(row,0).text())
            self.dbOperation.exitVehicle(id)
            self.table.removeRow(row)